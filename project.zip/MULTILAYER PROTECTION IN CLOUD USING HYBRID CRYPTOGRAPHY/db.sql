/*
SQLyog Community Edition- MySQL GUI v7.15 
MySQL - 5.5.29 : Database - file_split
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`file_split` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `file_split`;

/*Table structure for table `cloudadata` */

DROP TABLE IF EXISTS `cloudadata`;

CREATE TABLE `cloudadata` (
  `filename` VARCHAR(100) DEFAULT NULL,
  `owner` VARCHAR(100) DEFAULT NULL,
  `f1` TEXT,
  `skey` VARCHAR(100) DEFAULT NULL,
  `f2` TEXT,
  `skey1` VARCHAR(100) DEFAULT NULL,
  `f3` VARCHAR(100) DEFAULT NULL,
  `skey2` VARCHAR(100) DEFAULT NULL,
  `data` TEXT
) ENGINE=INNODB DEFAULT CHARSET=latin1;

/*Data for the table `cloudadata` */

INSERT  INTO `cloudadata`(`filename`,`owner`,`f1`,`skey`,`f2`,`skey1`,`f3`,`skey2`,`data`) VALUES ('shiva.txt','shiva','Q60qX8qjFmcmnb74/Azwkw==','c9sEYaDZeyvimVpZjy3/jw==','udtujiZoifc=','whCM1mFn2tY=','1uy/imCJs0Wofp003P23Lg==','Fj/dGbjeDjr+bR5S/wyuhQ==','hi hello how are you');

/*Table structure for table `file` */

DROP TABLE IF EXISTS `file`;

CREATE TABLE `file` (
  `id` INT(100) NOT NULL AUTO_INCREMENT,
  `file` TEXT,
  `filename` VARCHAR(50) DEFAULT NULL,
  `CDate` VARCHAR(20) DEFAULT NULL,
  `data` TEXT,
  `owner` VARCHAR(40) DEFAULT NULL,
  `pk` VARCHAR(40) DEFAULT NULL,
  `mk` VARCHAR(40) DEFAULT NULL,
  `privatekey` VARCHAR(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `file` */

INSERT  INTO `file`(`id`,`file`,`filename`,`CDate`,`data`,`owner`,`pk`,`mk`,`privatekey`) VALUES (4,'hi hello how are you','shiva.txt','2019-04-29','hi hello how are you\n','shiva','no','no',NULL);

/*Table structure for table `owner` */

DROP TABLE IF EXISTS `owner`;

CREATE TABLE `owner` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(1000) DEFAULT NULL,
  `dob` DATE DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `contact` VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (`id`,`username`),
  UNIQUE KEY `id` (`id`)
) ENGINE=INNODB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `owner` */

INSERT  INTO `owner`(`id`,`username`,`password`,`dob`,`email`,`city`,`contact`) VALUES (3,'shiva','shiva','1994-05-11','shiva@gmai.com','hyd','78965412130');

/*Table structure for table `request` */

DROP TABLE IF EXISTS `request`;

CREATE TABLE `request` (
  `filename` VARCHAR(40) NOT NULL,
  `data` TEXT,
  `owner` VARCHAR(40) DEFAULT NULL,
  `status` VARCHAR(40) DEFAULT NULL,
  `email` VARCHAR(40) DEFAULT NULL,
  `p1` VARCHAR(40) DEFAULT 'no',
  `p2` VARCHAR(40) DEFAULT 'no',
  `p3` BLOB,
  `s1` VARCHAR(100) DEFAULT 'no',
  `s2` VARCHAR(100) DEFAULT 'no',
  `s3` VARCHAR(100) DEFAULT 'no',
  PRIMARY KEY (`filename`)
) ENGINE=INNODB DEFAULT CHARSET=latin1;

/*Data for the table `request` */

INSERT  INTO `request`(`filename`,`data`,`owner`,`status`,`email`,`p1`,`p2`,`p3`,`s1`,`s2`,`s3`) VALUES ('shiva.txt','hi hello how are you','shiva','yes','shiva.1000projects@gmail.com','Q60qX8qjFmcmnb74/Azwkw==','udtujiZoifc=','1uy/imCJs0Wofp003P23Lg==','c9sEYaDZeyvimVpZjy3/jw==','whCM1mFn2tY=','Fj/dGbjeDjr+bR5S/wyuhQ==');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(1000) DEFAULT NULL,
  `dob` DATE DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `contact` VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (`id`,`username`),
  UNIQUE KEY `id` (`id`)
) ENGINE=INNODB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

INSERT  INTO `user`(`id`,`username`,`password`,`dob`,`email`,`city`,`contact`) VALUES (2,'krish','krish','1994-05-11','shiva.1000projects@gmail.com','hyd','9632587410');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
